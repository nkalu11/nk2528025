/* File:  Hello World
 * Author: Nnamdi Kalu
 * Created on June 25, 2014, 10:57 AM
 * Purpose First Program
 */

//System Level Libraries

#include <iostream>

using namespace std;

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    
//Print Simple Text
    cout <<"Hello World"<<endl;
    //Exit Stage Right
    return 0;
}

